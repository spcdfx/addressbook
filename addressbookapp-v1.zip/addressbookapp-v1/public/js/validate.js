$("form").submit(function (e) {
    
    var error = "";

    if ($("#title").val() == "") {
        error += "The title field is required.<br>"
    }

    if ($("#name").val() == "") {
        error += "The name field is required.<br>"
    }

    if ($("#companyName").val() == "") {
        error += "The Company Name field is required.<br>"
    }

    if ($("#jobTitle").val() == "") {
        error += "The Job title field is required.<br>"
    }

    if ($("#email").val() == "") {
        error += "The Email field is required.<br>"
    }

    if ($("#phoneNumber").val() == "") {
        error += "The Phone Number field is required.<br>"
    }

    if ($("#mobileNumber").val() == "") {
        error += "The Mobile Number field is required.<br>"
    }

    if ($("#address").val() == "") {
        error += "The Address field is required.<br>"
    }

    if ($("#notes").val() == "") {
        error += "The notes field is required."
    }

    if (error != "") {
        $("#error").html('<div class="alert alert-danger" role="alert"><p><strong>There were error(s) in your form</strong></p><br>' + error + '</div>');

        return false;

    } else {

        return true;

    }

    });