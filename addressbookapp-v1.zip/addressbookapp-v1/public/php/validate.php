<?php

$id = $_POST['id'];
$title = $_POST['title'];
$name = $_POST['name'];
$companyName = $_POST['companyName'];
$jobTitle = $_POST['jobTitle'];
$email = $_POST['email'];
$phoneNumber = $_POST['phoneNumber'];
$mobileNumber = $_POST['mobileNumber'];
$address = $_POST['address'];
$notes = $_POST['notes'];

if ($_POST) {
    
    if (!$_POST["title"]) {
        $error .= "Please enter a title.<br>";
    }

    if (!$_POST["name"]) {
        $error .= "Please enter a name.<br>";
    }

    if (!$_POST["companyName"]) {
        $error .= "Please enter a Company Name.<br>";
    }

    if (!$_POST["jobTitle"]) {
        $error .= "Please enter a Job Title.<br>";
    }

    if (!$_POST["email"]) {
        $error .= "Please enter an Email.<br>";
    }

    if (!$_POST["phoneNumber"]) {
        $error .= "Please enter a Phone Number.<br>";
    }

    if (!$_POST["mobileNumber"]) {
        $error .= "Please enter a Mobile Number.<br>";
    }

    if (!$_POST["address"]) {
        $error .= "Please enter an Address.<br>";
    }

    if (!$_POST["notes"]) {
        $error .= "Please enter a note.<br>";
    }

    if ($_POST["email"] && filter_var($_POST["email"], FILTER_VALIDATE_EMAIL) === false) {
        $error .="The email address is not valid";
    }

    if ($error != "") {
        $error = '<div class="alert alert-danger" role="alert"><p><strong>There were error(s) in your form</strong></p>' . $error . '</div>';
    } else { 
        $sql = "INSERT INTO contacts (id, title, name, companyName, jobTitle, email, phoneNumber, mobileNumber, address, notes)
        VALUES ('$id', '$title', '$name', '$companyName', '$jobTitle', '$email', '$phoneNumber', '$mobileNumber', '$address', '$notes')";
        

        if ($conn->query($sql) === TRUE) {
            $successMessage = '<div class="alert alert-success" role="alert">Your contact was created successfully</div>';
            header("Location: index.php?startrow=".$_GET['startrow']."");

            
        } else {
            $error = '<div class="alert alert-danger" role="alert">Your contact could not be created - please try again later</div>';
        }
    }

}
?>