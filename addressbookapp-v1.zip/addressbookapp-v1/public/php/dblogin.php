<?php

include 'dbloginvalues.php';

if (!isset($_GET['startrow']) or !is_numeric($_GET['startrow'])) {
    $startrow = 0;
} else {
    $startrow = (int)$_GET['startrow'];
}

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = "SELECT * FROM contacts LIMIT $startrow, 5";

$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}

?>