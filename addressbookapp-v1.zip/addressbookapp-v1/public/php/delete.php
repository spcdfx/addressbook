<?php
$id = $_GET['id'];
include 'dbloginvalues.php';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

if (!isset($_GET['id']) or !is_numeric($_GET['id'])) {
    $startrow = 0;
} else {
    $startrow = (int)$_GET['startrow'];
}

$sql = "DELETE FROM contacts WHERE id = $id";

if (mysqli_query($conn, $sql)) {
    mysqli_close($conn);
    header('Location: ../index.php');
    exit;
} else {
    echo "There was an error deleting contact.";
}

?>