<?php

include 'dbloginvalues.php';
$search = $_GET['search'];

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = "SELECT * FROM contacts WHERE name LIKE '$search%'";

$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}

include 'validate.php';

?>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../../bootstrap/compiled/bootstrap.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="https://use.fontawesome.com/1465482b10.js"></script>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <title>Address Book</title>
    </head>

    <div class="container-fluid" id="titleContainer">
            <div class="row">
                <div class="col-10">
                    <a href="../index.php"><h1 class="appTitle"><i class="fa fa-address-book fa-1x"></i> Address Book</h1></a>
            <!--    <p class="appTitleSub">Created by William Bray</p> -->
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-3">
                        <form method="get">
                        <input type="text" class="form-control" name="search" placeholder="Enter Full Name">
                    </div>
                    <div class="col-1">
                        <?php
                        echo '<button type="submit" class="btn btn-primary" id="searchButton"><i class="fa fa-search fa-lg"></i></button>';
                        ?>
                        </form>
                    </div>
                </div>
            </div>
    </div>

    <div class="row justify-content-center">
                <div class="table-responsive" id="myTable">
                    <table class="table table-striped table-bordered" id="addressTable">
                        <thead>
                            <tr>
                            <th style="text-align:center; vertical-align:middle; display: none;">id</th>
                            <th style="text-align:center; vertical-align:middle;">Title</th>
                            <th style="text-align:center; vertical-align:middle;">Name</th>
                            <th style="text-align:center; vertical-align:middle;">Company Name</th>
                            <th style="text-align:center; vertical-align:middle;">Job title</th>
                            <th style="text-align:center; vertical-align:middle;">Email</th>
                            <th style="text-align:center; vertical-align:middle;">Phone Number</th>
                            <th style="text-align:center; vertical-align:middle;">Mobile Number</th>
                            <th style="text-align:center; vertical-align:middle;">Address</th>
                            <th style="text-align:center; vertical-align:middle;">Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        while ($row = mysqli_fetch_array($query))
                        {
                            echo '<tr>
                                    <td style="text-align:center; vertical-align:middle; display: none;">'.$row['id'].'</td>                            
                                    <td style="text-align:center; vertical-align:middle;">'.$row['title'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['name'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['companyName'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['jobTitle'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['email'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['phoneNumber'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['mobileNumber'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['address'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['notes'].'</td>
                                </tr>';
                        }?>
                        </tbody>
                        <tfoot>
                        </tfoot>
                    </table>
                </div>
            </div>