<?php

// Please edit this values as needed to log into your database.

$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = 'password'; // Password
$db_name = 'contacts'; // Database Name

?>