<?php

require __DIR__.'/../bootstrap/autoload.php';

$app = require_once __DIR__.'/../bootstrap/app.php';

include 'php/dblogin.php';
include 'php/validate.php';

$error = "";
$successMessage = "";
$prev = $startrow - 5;


?>

<html>
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../bootstrap/compiled/bootstrap.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    <script src="https://use.fontawesome.com/1465482b10.js"></script>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Address Book</title>
    </head>
    <body>
        <div class="container-fluid" id="titleContainer">
            <div class="row">
                <div class="col-10">
                    <a href="javascript:window.location.reload(true)"><h1 class="appTitle"><i class="fa fa-address-book fa-1x"></i> Address Book</h1></a>
            <!--    <p class="appTitleSub">Created by William Bray</p> -->
                </div>
                <div class="col-2 align-self-end">
                <button type="button" class="btn btn-primary" id="myButton" name="Add"><i class="fa fa-plus fa-lg"></i>Add Contact</button>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">

                    <div class="col-1">
                        <form method="get">
                        <?php
                        echo '<a href="php/search.php" class="btn btn-primary" id="searchButton"><i class="fa fa-search fa-lg"></i></a>';
                        ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
            <div class="container" id="error"><br><? echo $error.$successMessage; ?></div>
            </div>
            <div class="row justify-content-center">
                <div class="container" id="addDiv" style="display:none;">
                        <form method="post" stlye="position:absolute;">
                            <div class="row">
                                <div class="col-sm-12 col-md-4 col-lg-4">
                                    <div class="form-group">
                                        <label for="title">Title</label>
                                        <input type="text" class="form-control" method="post" id="title" name="title" id="inputTitle" placeholder="Enter Title">
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" method="post" id="name" name="name" id="inputName" placeholder="Enter Name">
                                    </div>
                                    <div class="form-group">
                                        <label for="companyName">Company Name</label>
                                        <input type="text" class="form-control" method="post" id="companyName" name="companyName" id="inputCompanyName" placeholder="Enter Company Name">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-4">
                                    <div class="form-group">
                                        <label for="jobTitle">Job Title</label>
                                        <input type="text" class="form-control" method="post" id="jobTitle" name="jobTitle" id="inputJobTitle" placeholder="Enter Job Title">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email Address</label>
                                        <input type="email" class="form-control" method="post" id="email" name="email" id="InputEmail" placeholder="Enter Email Address">
                                    </div>
                                    <div class="form-group">
                                        <label for="phoneNumber">Phone Number</label>
                                        <input type="text" class="form-control" method="post" id="phoneNumber" name="phoneNumber" id="inputPhoneNumber" placeholder="Enter Phone Number">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-4">
                                    <div class="form-group">
                                        <label for="mobileNumber">Mobile Number</label>
                                        <input type="text" class="form-control" method="post" id="mobileNumber" name="mobileNumber" id="inputMobileNumber" placeholder="Enter Mobile Number">
                                    </div>
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" class="form-control" method="post" id="address" name="address" id="inputAddress" placeholder="Enter Address">
                                    </div>
                                    <div class="form-group">
                                        <label for="notes">Notes</label>
                                        <textarea class="form-control" id="notes" name="notes" rows="1"></textarea>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" id="submit" class="btn btn-primary" onclick="clearform();">Submit</button>
                        </form>
                    </div>
            </div>

        
            <div class="row justify-content-center">
                <div class="table-responsive" id="myTable">
                    <table class="table table-striped table-bordered" id="addressTable">
                        <thead>
                            <tr>
                            <th style="text-align:center; vertical-align:middle; display: none;">id</th>
                            <th style="text-align:center; vertical-align:middle;">Title</th>
                            <th style="text-align:center; vertical-align:middle;">Name</th>
                            <th style="text-align:center; vertical-align:middle;">Company Name</th>
                            <th style="text-align:center; vertical-align:middle;">Job title</th>
                            <th style="text-align:center; vertical-align:middle;">Email</th>
                            <th style="text-align:center; vertical-align:middle;">Phone Number</th>
                            <th style="text-align:center; vertical-align:middle;">Mobile Number</th>
                            <th style="text-align:center; vertical-align:middle;">Address</th>
                            <th style="text-align:center; vertical-align:middle;">Notes</th>
                            <th style="text-align:center; vertical-align:middle;">Edit & Delete Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        while ($row = mysqli_fetch_array($query))
                        {
                            $amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);
                            echo '<tr>
                                    <td style="text-align:center; vertical-align:middle; display: none;">'.$row['id'].'</td>                            
                                    <td style="text-align:center; vertical-align:middle;">'.$row['title'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['name'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['companyName'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['jobTitle'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['email'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['phoneNumber'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['mobileNumber'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['address'].'</td>
                                    <td style="text-align:center; vertical-align:middle;">'.$row['notes'].'</td>
                                    <td style="text-align:center; vertical-align:middle;"><button type="submit" class="btn btn-info" name="editContact"><i class="fa fa-pencil fa-lg"></i></button><br><br><a href="php/delete.php?id='.$row['id'].'" class="btn btn-danger" method="get" name="deleteContact"><i class="fa fa-times fa-lg"></i></a></td>
                                </tr>';
                        }?>
                        </tbody>
                        <tfoot>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-12 align-self-center"> 
                    <? if ($prev >= 0) echo '<a href="'.'?startrow='.$prev.'" style="padding-right:15px;">Previous</a>'; echo '<a href="'.'?startrow='.($startrow+5).'">Next</a>'; ?>
                </div>
            </div>
        </div>
        <script>
        $('#myButton').click(function() {
            $('#addDiv').toggle('slow', function() {
            });
        });
    </script>
    <script src="js/validate.js"></script>
    </body>
</html>